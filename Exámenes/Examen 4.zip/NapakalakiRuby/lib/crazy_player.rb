# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

# Examen-inicio

require_relative "cultist_player.rb"

class CrazyPlayer < CultistPlayer
  
  def initialize(p, c, m)
    super(p, c)
    @madnessLevel = m
  end
  
  def do_crazy
    raise NotImplementedError.new
  end
  
  # Para utilizar esta clase como abstracta
  private_class_method :new
  
end

# Examen-fin
